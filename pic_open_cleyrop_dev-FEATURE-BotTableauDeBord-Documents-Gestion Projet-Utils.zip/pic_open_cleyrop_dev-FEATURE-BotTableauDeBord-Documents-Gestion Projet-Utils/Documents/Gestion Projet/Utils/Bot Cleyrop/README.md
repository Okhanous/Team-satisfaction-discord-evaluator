# For virtualenv to install all files in the requirements.txt file.

* cd to the directory where requirements.txt is located
* activate your virtualenv
* run: pip install -r requirements.txt in your shell
